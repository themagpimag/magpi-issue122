secrets = {
    'ssid': 'Enter_your_SSID_here',
    'pw': 'Enter_your_Wi-Fi_password_here',
    }

# Original Pico W LED web server scripts by Nathen Busler at https://github.com/pi3g/pico-w/tree/main/MicroPython/I%20Pico%20W%20LED%20web%20server